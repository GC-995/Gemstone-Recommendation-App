# AI Usage Declaration

AI assistance was used to help design and implement this assessment project.

## How AI Was Used

- Generated the initial frontend structure.
- Helped create gemstone metadata and scoring logic.
- Assisted with responsive CSS and UI copy.
- Drafted README and project notes.

## Human Responsibility

The final project should be reviewed by the submitting candidate before submission. The candidate is responsible for understanding the code, explaining the architecture, and verifying that the implementation meets the assessment requirements.

## Limitations

The app provides lifestyle-oriented gemstone recommendations only. It does not provide medical, financial, or guaranteed astrological advice.
